import base64
import json
import os
import pathlib
import re
import subprocess
import sys
import time

backend = sys.argv[1]
root = pathlib.Path('/tmp/asr-wire-' + backend + '-20261108-v2')
root.mkdir(exist_ok=False)
env = os.environ.copy()
env.update(GRPC_ASR_BACKEND=backend, GRPC_ASR_MODELS='tiny.en',
           GRPC_ASR_MODELS_DIR='/work/main/grpc-services/grpc-asr/models',
           GRPC_ASR_THREADS='2', GRPC_ASR_CONCURRENCY='1',
           GRPC_ASR_WINDOW_SECONDS='30', GRPC_ASR_LISTEN_ADDRESS='127.0.0.1:51055',
           GRPC_ASR_TRACE_PLACEMENT='1')
service = 'ai.pipestream.asr.v1.AsrService/'
command = ['grpcurl', '-plaintext', '-max-time', '60', '-d', '@', '127.0.0.1:51055']
log = (root / 'server.log').open('w')
server = subprocess.Popen(['/tmp/asr-cuda-qualified-9ce6f52/grpc-asr-server'], env=env, stdout=log, stderr=log)
try:
    for attempt in range(100):
        info = subprocess.run(command + [service + 'GetServiceInfo'], input='{}', text=True, capture_output=True)
        if info.returncode == 0:
            break
        assert server.poll() is None, 'server exited at startup'
        time.sleep(.1)
    assert info.returncode == 0, info.stderr
    (root / 'info.json').write_text(info.stdout)
    wav = pathlib.Path('/work/main/grpc-services/worktrees/grpc-asr-cuda-20261108/deps/whisper-pinned/samples/jfk.wav').read_bytes()
    payload = json.dumps({'options': {'model': 'tiny.en', 'language': 'en', 'wordTimestamps': True, 'emitDocument': True}}) + '\n'
    payload += '\n'.join(json.dumps({'chunk': {'data': base64.b64encode(wav[i:i+32768]).decode()}}) for i in range(0, len(wav), 32768))
    for repeat in range(2):
        result = subprocess.run(command + [service + 'Transcribe'], input=payload, text=True, capture_output=True)
        (root / f'output-{repeat}.jsonl').write_text(result.stdout)
        (root / f'output-{repeat}.stderr').write_text(result.stderr)
        assert result.returncode == 0, result.stderr
        remaining = result.stdout.strip()
        events = []
        while remaining:
            event, end = json.JSONDecoder().raw_decode(remaining)
            events.append(event)
            remaining = remaining[end:].lstrip()
        finals = [e['final_segment'] for e in events if 'final_segment' in e]
        text = ' '.join(s['text'] for s in finals)
        normalized = re.sub(r'[^a-z ]', '', text.lower())
        normalized = ' '.join(normalized.split())
        for phrase in ('my fellow americans', 'ask not what your country can do for you', 'ask what you can do for your country'):
            assert phrase in normalized, (phrase, text)
        assert 'media_info' in events[0] and 'complete' in events[-1]
        assert int(events[-1]['complete']['segment_count']) == len(finals)
        assert sum('document' in e for e in events) == 1
        last = 0
        for i, segment in enumerate(finals):
            start, end = int(segment.get('start_ms', 0)), int(segment.get('end_ms', 0))
            assert int(segment.get('index', 0)) == i and last <= start < end <= 12000
            last = start
            assert segment.get('words'), 'missing word timestamps'
            for word in segment['words']:
                assert 0 <= int(word.get('start_ms', 0)) <= int(word.get('end_ms', 0)) <= 12000
        print(backend, repeat, 'full JFK text + segment/word timestamps + document + trailer PASS:', text, flush=True)
finally:
    server.terminate()
    try:
        server.wait(timeout=10)
    except subprocess.TimeoutExpired:
        server.kill()
        server.wait()
    log.close()
