#!/bin/bash
set -euo pipefail
cd /work/main/grpc-services/worktrees/grpc-asr-cuda-20261108
export GRPC_ASR_TEST_MODEL=/work/main/grpc-services/grpc-asr/models/ggml-tiny.en.bin
export GRPC_ASR_TEST_SAMPLE="$PWD/deps/whisper-pinned/samples/jfk.wav"
export GRPC_ASR_SERVER_BINARY="$PWD/build-cuda/grpc-asr-server"
ctest --test-dir build-cuda -R '^(state-ownership|sniff|pcm-scrub|byte-stream|config|remote-options|docling-asr-options|audio-decoder|document-fold|model-discovery|window-cut|transcriber|video-demux|grpc-openssl|stream-backend)-test$' --output-on-failure >/tmp/asr-final-units.log 2>&1
GRPC_ASR_TEST_BACKEND=cuda GRPC_ASR_TRACE_PLACEMENT=1 ./build-cuda/asr-service-test >/tmp/asr-final-cuda-rpc.log 2>&1
GRPC_ASR_TEST_BACKEND=cuda GRPC_ASR_TRACE_PLACEMENT=1 GRPC_ASR_TEST_MEDIA_TIMELINE_ONLY=1 ./build-cuda/asr-service-test >/tmp/asr-final-cuda-timeline.log 2>&1
GRPC_ASR_TEST_BACKEND=cpu GRPC_ASR_TEST_MEDIA_TIMELINE_ONLY=1 ./build-cuda/asr-service-test >/tmp/asr-final-cpu-timeline.log 2>&1
