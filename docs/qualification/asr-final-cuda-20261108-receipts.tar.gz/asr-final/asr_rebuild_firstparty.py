"""Rebuild first-party targets using CMake's exact generated commands.

The interrupted parallel Ninja writers damaged dependency bookkeeping.
Reuse the already qualified, pinned dependency archives; never infer that
first-party objects are current from that damaged cache. Compile every
first-party translation unit and the canonical generated Whisper unit,
then run the generated archive/link commands in dependency order.
"""
import concurrent.futures
import hashlib
import pathlib
import shlex
import subprocess

repo = pathlib.Path('/work/main/grpc-services/worktrees/grpc-asr-cuda-20261108')
build = repo / 'build-cuda'
commands = subprocess.check_output(['ninja', '-t', 'commands', 'grpc-asr-server', 'grpc-asr-tests'], cwd=build, text=True).splitlines()
compile_commands, link_commands, reused = [], [], set()
prefixes = tuple(str(repo / p) + '/' for p in ('src', 'tests', 'streaming/src', 'streaming/tests', 'build-cuda/generated', 'build-cuda/streaming'))
for command in commands:
    parts = shlex.split(command)
    if '-c' in parts:
        source = parts[parts.index('-c') + 1]
        if source.startswith(prefixes) or source == str(build / 'observed-whisper.cpp'):
            compile_commands.append(command)
        continue
    archive = parts[parts.index('qc') + 1] if 'qc' in parts else ''
    output = parts[parts.index('-o') + 1] if '-o' in parts else ''
    if (archive.startswith('libasr_') or archive.startswith('streaming/libmedia_') or
        archive == '_deps/whisper-build/src/libwhisper.a' or
        output == 'grpc-asr-server' or ('/' not in output and output.endswith('-test'))):
        link_commands.append(command)
        for part in parts:
            if part.endswith('.a') and part.startswith('_deps/') and part != '_deps/whisper-build/src/libwhisper.a':
                reused.add(part)
assert compile_commands and link_commands
def digest(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
before = {p: digest(build / p) for p in sorted(reused)}
pathlib.Path('/tmp/asr-native-reused-dependencies.sha256').write_text(''.join(f'{h}  {p}\n' for p, h in before.items()))
pathlib.Path('/tmp/asr-native-firstparty-commands.txt').write_text('\n'.join(compile_commands + link_commands) + '\n')
def execute(command):
    result = subprocess.run(command, shell=True, cwd=build, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(command + '\n' + result.stdout)
    return result.stdout
print(f'Compiling {len(compile_commands)} fresh units with two jobs; {len(link_commands)} generated archive/link commands', flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for index, output in enumerate(pool.map(execute, compile_commands), 1):
        print(f'compile {index}/{len(compile_commands)} PASS', flush=True)
        if output:
            print(output, flush=True)
for index, command in enumerate(link_commands, 1):
    output = execute(command)
    print(f'link {index}/{len(link_commands)} PASS', flush=True)
    if output:
        print(output, flush=True)
assert before == {p: digest(build / p) for p in sorted(reused)}, 'reused dependency archive changed'
print('Fresh first-party build PASS; qualified dependency archive hashes unchanged', flush=True)
