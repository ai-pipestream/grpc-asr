import pathlib,subprocess,shlex,os
root=pathlib.Path('/work/main/grpc-services/worktrees/grpc-asr-cuda-20261108'); build=root/'build-cuda'; temp=pathlib.Path('/tmp/asr-pcm-compare');temp.mkdir(exist_ok=True)
s=(root/'tests/transcriber_test.cpp').read_text()
a=s.index('                require(result.duration_ms == duration_ms');b=s.index('\n            }',a)
s=s[:a]+'''                std::println("CASE window={} delay={} words={} duration={} tokens={} finals={}", window, delay_ms, words, result.duration_ms, result.tokens, result.final_segments);
                for (const auto& event : events) {
                    const auto& x = event.segment;
                    std::println("META final={} index={} tokens={} confidence={:a} speaker={} turn={} text={}", event.final, x.index, x.token_count, x.avg_logprob, x.speaker, x.speaker_turn_next, x.text);
                    std::println("TIME {} {} available={}", x.start_ms, x.end_ms, event.available_ms);
                    for (const auto& w : x.words) {
                        std::println("WORD probability={:a} text={}", w.probability, w.text);
                        std::println("TIME {} {}", w.start_ms, w.end_ms);
                    }
                }'''+s[b:]
(temp/'probe.cpp').write_text(s)
cmds=subprocess.check_output(['ninja','-t','commands','transcriber-test'],cwd=build,text=True).splitlines()
compilecmd=next(shlex.split(c) for c in cmds if ' -c ' in c and '/tests/transcriber_test.cpp' in c)
compilecmd[compilecmd.index('-c')+1]=str(temp/'probe.cpp');compilecmd[compilecmd.index('-o')+1]=str(temp/'probe.o');compilecmd+=['-I'+str(root/'tests')]
subprocess.run(compilecmd,cwd=build,check=True)
link=next(c for c in cmds if ' -o transcriber-test ' in c)
for label,lib in [('old','/tmp/asr-pcm-raw/libasr_core.a'),('new',str(build/'libasr_core.a'))]:
 command=link.replace('CMakeFiles/transcriber-test.dir/tests/transcriber_test.cpp.o',str(temp/'probe.o')).replace(' -o transcriber-test ',f' -o {temp}/{label} ').replace(' libasr_core.a ',f' {lib} ')
 subprocess.run(command,shell=True,cwd=build,check=True)
 env=dict(os.environ,GRPC_ASR_TEST_MODEL='/work/main/grpc-services/grpc-asr/models/ggml-tiny.en.bin',GRPC_ASR_TEST_SAMPLE=str(root/'deps/whisper-pinned/samples/jfk.wav'))
 with (temp/(label+'.log')).open('w') as out: subprocess.run([str(temp/label)],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
lines=lambda label:[s for s in (temp/(label+'.log')).read_text().splitlines() if s.startswith(('CASE','META','WORD'))]
a,b=lines('old'),lines('new');assert a==b,'non-timestamp output differs'
(temp/'comparison.txt').write_text(f'PASS exact non-timestamp output: {len(a)} case/segment/word records; all 8 settings, old versus new. Float confidence/probability serialized hexadecimal.\n')
print((temp/'comparison.txt').read_text())
